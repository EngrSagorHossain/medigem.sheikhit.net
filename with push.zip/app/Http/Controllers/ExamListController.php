<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ExamListController extends Controller
{
    //
}
